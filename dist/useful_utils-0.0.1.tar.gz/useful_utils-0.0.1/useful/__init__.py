"""Init file for useful package."""

from useful.test_suite import TestSuite
from useful.benchmark import Benchmark

__all__ = ["TestSuite", "Benchmark"]
